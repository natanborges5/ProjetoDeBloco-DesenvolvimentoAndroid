package br.natan.borges.tp3_projetodebloco

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_calculadora5.*

class Calculadora5Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculadora5)

        buttonCalcule.setOnClickListener {
            calculadora()
        }
    }
    private fun calculadora(){
        var salariof = salario.text.toString()
        var numero = number.text.toString()
        var salarioFloat = salariof.toFloat()
        var numeroInt = numero.toInt()
        var resultado = (salarioFloat / 30) * numeroInt

        viewResultado.text = resultado.toString()
    }
}