package br.natan.borges.tp3_projetodebloco

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        buttonCalculadora1.setOnClickListener {
            var calculadoraIntent1 = Intent(
                this,
                Calculadora1Activity::class.java
            )
            startActivity(calculadoraIntent1)
        }
    }
}