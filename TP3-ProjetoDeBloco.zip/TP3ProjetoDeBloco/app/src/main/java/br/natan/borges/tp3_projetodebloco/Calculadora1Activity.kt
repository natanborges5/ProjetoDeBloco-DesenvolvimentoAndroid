package br.natan.borges.tp3_projetodebloco

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_calculadora1.*

class Calculadora1Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculadora1)

         buttonCalcular.setOnClickListener {
             Calculadora()
        }

    }
    private fun Calculadora(){
        var valorConta = editTextValorDaConta.text.toString()
        var pessoas = editTextNumeroDePessoas.text.toString()
        var valorContaf = valorConta.toFloat() * 1.1
        var pessoasf = pessoas.toInt()
        var resultado = valorContaf / pessoasf

        textViewResultado.text = resultado.toString()
    }
}