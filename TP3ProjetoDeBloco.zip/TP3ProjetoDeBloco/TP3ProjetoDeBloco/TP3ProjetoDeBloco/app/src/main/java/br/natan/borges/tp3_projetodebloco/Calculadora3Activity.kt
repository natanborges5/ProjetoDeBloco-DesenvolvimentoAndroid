package br.natan.borges.tp3_projetodebloco


import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Calculadora3Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculadora3)

        val textView: TextView = findViewById(R.id.textView)
        val button: Button = findViewById(R.id.button)
        val editTextNumberDecimal: EditText = findViewById(R.id.editTextNumberDecimal)

        button.setOnClickListener{
            val click = editTextNumberDecimal.text.toString().toDouble()
            textView.text = converter(click).toString()
        }
    }
    private fun converter(f: Double): Double {return (f-32)/1.8 }
}