package br.natan.borges.tp3_projetodebloco

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

import android.view.View


class Calculadora2Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculadora2)

        val textView: TextView = findViewById<TextView>(R.id.textView)
        val button: Button = findViewById<Button>(R.id.button)
        val editText: EditText = findViewById<EditText>(R.id.editText)


        button.setOnClickListener {
            val str = editText.text.toString().toInt()

            textView.text = multiplyNumbers(str).toString()
        }


    }

    fun multiplyNumbers(num: Int): Long {
        if (num >= 1)
            return num * multiplyNumbers(num - 1)
        else
            return 1
    }

}